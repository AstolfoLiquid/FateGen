const express = require('express');
const router = express.Router();
const fetch = require('node-fetch')

/* GET home page. */
router.post('/', function(req, res, next) {
    const info = req.body.accountcheck;
    if(!info.includes(':')) {
        return res.render('gen', { status: 'Invalid, please use email:password format.' })
    }
    const stuff = info.split(':')
    const email = stuff[0];
    const password = stuff[1];
    const body = JSON.stringify({
        agent: {                             
            name: "Minecraft",                
            version: 1                        
                                                
        },
        username: email,      
                                                
        password: password,
        requestUser: true                   
    });
    console.log(body)
    fetch(`http://auth.mojang.com//authenticate`, {
        method: "POST",
        body: body,
        headers: {
            "Content-type": "application/json"
        }
    }).then(res => res.json()).then(json => {
        console.log(json)
        if(json.error === undefined) {
            res.render("gen", { status: "Account works!" })
        } else {
            res.render("gen", { status: "Account does not work or you are IP-Banned from mojang api" })
        }
    })
    
});

module.exports = router;