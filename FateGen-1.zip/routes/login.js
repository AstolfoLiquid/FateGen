const express = require('express');
const router = express.Router();
const firebase = require('firebase')
require('firebase/auth')
const app = firebase.initializeApp({
  // Firebase Stuff
})


/* GET home page. */
router.get('/', function(req, res, next) {
  firebase.auth().onAuthStateChanged((user) => {
    if(user) {
      res.redirect('/client/gen')
    } else {
      res.render('login')
    }
  })
});

module.exports = router;
